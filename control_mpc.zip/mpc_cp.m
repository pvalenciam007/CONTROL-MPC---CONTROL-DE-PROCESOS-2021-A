clc
close all
clear all
%load('mpc1.mat')
%% Define o processo da Coluna:
Ps=[tf(12.8,[16.7 1]) tf(-18.9,[21 1]);tf(6.6,[10.9 1]) tf(-19.4,[14.4 1])];
Ps.iodelay=[1 3;7 3]; %Define o Atraso

%% Define o modelo do processo da Coluna:
Pm= Ps;
Pm.iodelay=[1 3;7 3]+2; %Define o Atraso

%% Define a perturbacao
Pq=[tf(3.8,[14.9 1]);tf(4.9,[13.2 1])];
Pq.iodelay=[8.1;3.4]; %Define o Atraso

%% Define o modelo da perturbacao
Pmq=Pq;
Pmq.iodelay=[8.1;3.4]+1; %Define o Atraso

DC=[Pm Pmq];
DC.InputName = {'Caudal de reflujo', 'Caudal de vapor', 'Caudal de alimentaci�n'};
DC.OutputName = {'Pureza destilada tope', 'Pureza en la base'};
DC = setmpcsignals(DC, 'MD', 3)

%% Parametros do Simulink
s1=1;     %SetPoint no Topo
s2=0.5;   %SetPoint no Fundo
q=0.3;    %Degrau na perturbacao